---
name: Arcade Espacial Educativo
colors:
  surface: '#021523'
  surface-dim: '#021523'
  surface-bright: '#293b4b'
  surface-container-lowest: '#000f1d'
  surface-container-low: '#091d2c'
  surface-container: '#0e2130'
  surface-container-high: '#192c3b'
  surface-container-highest: '#243746'
  on-surface: '#d1e5f9'
  on-surface-variant: '#bbc9c8'
  inverse-surface: '#d1e5f9'
  inverse-on-surface: '#203242'
  outline: '#869392'
  outline-variant: '#3c4948'
  surface-tint: '#53dad6'
  primary: '#affffb'
  on-primary: '#003736'
  primary-container: '#64e8e4'
  on-primary-container: '#006765'
  inverse-primary: '#006a68'
  secondary: '#e6c44c'
  on-secondary: '#3b2f00'
  secondary-container: '#ac8e15'
  on-secondary-container: '#332900'
  tertiary: '#e7f2ff'
  on-tertiary: '#003351'
  tertiary-container: '#b0d9ff'
  on-tertiary-container: '#006193'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74f6f2'
  primary-fixed-dim: '#53dad6'
  on-primary-fixed: '#00201f'
  on-primary-fixed-variant: '#00504e'
  secondary-fixed: '#ffe17c'
  secondary-fixed-dim: '#e6c44c'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#564500'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#92ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#021523'
  on-background: '#d1e5f9'
  surface-variant: '#243746'
typography:
  headline-xl:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Rubik, 'Trebuchet MS', sans-serif
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: JetBrains Mono, Consolas, 'Courier New', monospace
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: JetBrains Mono, Consolas, 'Courier New', monospace
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: JetBrains Mono, Consolas, 'Courier New', monospace
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono, Consolas, monospace
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono, Consolas, monospace
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono, Consolas, monospace
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

O design system estabelece a identidade de um ambiente de aprendizagem lúdico, combinando a nostalgia do fliperama espacial com o rigor técnico do desenvolvimento de software. Voltado para estudantes iniciantes e entusiastas de programação de jogos, o universo visual equilibra acolhimento pedagógico e dinamismo interativo.

### Personalidade e Tom
- **Gamificado e Encorajador:** O erro de sintaxe não é punitivo, mas parte da mecânica de jogo. A interface celebra marcos de progresso com brilhos táteis e feedback sonoro visual.
- **Técnico-Acessível:** Une a clareza de blocos de comando à estética de consoles espaciais, transformando lógica de programação em componentes visuais intuitivos.
- **Retro-Moderno Limpo:** Evita ruído visual excessivo dos jogos de 8 bits em favor de linhas vetoriais poligonais limpas, superfícies escuras contrastantes e iluminação por ciano e âmbar.

### Linguagem Visual Vetorial
A iconografia e os avatares utilizam construções geométricas puras (robôs em blocos chanfrados, naves angulares pontiagudas, cristais de quartzo em hexágonos e campos estelares vetoriais). A estética afasta-se do realismo para abraçar interfaces de comando orbital inspiradas em HUDs amigáveis de ficção científica pedagógica.

## Colors

A paleta é estruturada para imersão em cabine espacial, alto contraste sob conformidade WCAG AAA em elementos textuais e distinção imediata de estados funcionais.

### Paleta Principal
- **Background Espacial (`#080F1A`):** Fundo absoluto com profundidade cósmica fria, reduzindo a fadiga visual durante sessões prolongadas de codificação.
- **Painéis e Superfícies (`#102332`):** Superfície de primeiro plano para cartões, bandejas de código e HUDs operacionais.
- **Bordas Estruturais (`#1C3B54`):** Delimitação precisa de quadrantes e contêineres de interação.
- **Destaque Ciano (`#64E8E4`):** Cor primária de ação, foco, compilação de código, links ativos e estados concluídos com sucesso.
- **Destaque Amarelo (`#F9D65C`):** Cor secundária para pontuações, coletáveis, energia estelar e avisos de sintaxe sem bloqueio.

### Tipografia e Contraste
- **Texto Principal (`#EDF6FF`):** Branco gelo de alto contraste, garantindo leitura instantânea sobre fundos escuros.
- **Texto Secundário (`#9EB5C9`):** Azul acinzentado neutro para metadados, dicas de ferramentas e linhas de depuração passivas.
- **Alerta e Erro (`#FF5C77`):** Vermelho laser saturado para exceções de execução e nós com colisão.

## Typography

A tipografia do sistema reflete a duplicidade do projeto: a amigabilidade dos títulos arredondados acolhe o jovem programador, enquanto o corpo técnico em fonte monoespaçada condiciona a familiaridade com ambientes reais de desenvolvimento (IDEs).

- **Títulos (`Rubik` com fallbacks em `Trebuchet MS`, `sans-serif`):** Conduzem a navegação do arcade. Geometria humanizada e curvaturas suaves diminuem a barreira de entrada da lógica matemática.
- **Corpo e Dados (`JetBrains Mono` com fallbacks em `Consolas`, `'Courier New'`, `monospace`):** Alinhamento tabular natural para exibição de variáveis de coordenadas `(x, y)`, matrizes, loops e instruções. Todas as linhas de código pedagógico mantêm proporção fixa de caracteres.
- **Rótulos HUD:** Apresentados com leve tracking ampliado para simular legendas de instrumentação aeroespacial.

## Layout & Spacing

O layout emprega uma malha fluida modular preparada para alternar entre o painel de execução (canvas de visualização do jogo) e o console de blocos/código.

### Grid e Breakpoints
- **Mobile (< 768px):** Layout em coluna única ou abas com alternância rápida entre "Simulação" e "Editor". Margem externa de `1rem`, calhas de `0.75rem`. Alvos táteis preservados com folgas dedicadas.
- **Tablet (768px - 1024px):** Grid de 8 colunas com proporção mista (editor de instruções empilhado ou em tela dividida 50/50).
- **Desktop (> 1024px):** Grid de 12 colunas assimétrico com divisão 7/5 (7 colunas para o workspace de lógica/código e 5 colunas para o simulador em tempo real e telemetria de missões).

### Ritmo Espacial
Todas as dimensões vazias derivam de múltiplos estritos de 4px e 8px. Módulos empilhados mantêm gap padrão de `space-md` (`1rem`), expandindo para `space-xl` (`2.5rem`) apenas na separação entre zonas globais de comando e a barra de ferramentas de apoio.

## Elevation & Depth

O design system rejeita sombras difusas realistas em prol de uma hierarquia tátil de arcade cibernético baseada em contornos de alta nitidez, superfícies iluminadas e sombras duras deslocadas.

- **Nível 0 (Vácuo/Fundo):** Superfície sólida `#080F1A` pontilhada sutilmente por estrelas vetoriais estáticas.
- **Nível 1 (Módulos e Painéis):** Superfície `#102332` contornada por borda sólida de `1px` em `#1C3B54`.
- **Nível 2 (Componentes Interativos e Cartões de Missão):** Superfície `#152E42` com borda de `1px` em `#275273` e deslocamento tátil de profundidade (`box-shadow: 0 4px 0 #0A1621`).
- **Nível 3 (Flutuantes, Modais e Destaques Ativos):** Borda retroiluminada em `#64E8E4` com brilho de néon contido (`box-shadow: 0 0 12px rgba(100, 232, 228, 0.25), 0 4px 0 #05101A`).
- **Foco e Acessibilidade:** Foco visível global estabelecido por anel duplo: `2px solid #64E8E4` com recuo `offset` de `2px` em `#080F1A`, garantindo detecção imediata tanto por mouse quanto por navegação assistiva via teclado ou switch-access.

## Shapes

O nível de arredondamento 2 estabelece bordas arredondadas de `0.5rem` (`8px`) para elementos base, conferindo uma natureza amigável e segura para crianças e jovens sem perder o rigor geométrico dos painéis espaciais.

- **Cantos Base (`0.5rem` / `8px`):** Botões, inputs, blocos de comando individuais, badges e chips de inventário.
- **Contêineres Médios (`1rem` / `16px`):** Cartões de missão, visor do emulador do jogo e gaveta de inventário de assets.
- **Formatos Chanfrados Especiais:** Marcadores de fase e chips de XP utilizam recortes angulares calculados em 45 graus via `clip-path` nas extremidades, reforçando a assinatura de arcade futurista.

## Components

Todos os componentes interativos cumprem a dimensão mínima de toque de **44px × 44px** para garantir usabilidade total em telas sensíveis ao toque de tablets escolares e smartphones.

### Botões
- **Primário (Ação / Executar Código):** Fundo ciano `#64E8E4`, texto `#080F1A` em negrito, altura mínima de `48px`. No estado normal, possui base deslocada `box-shadow: 0 4px 0 #349E9B`. No clique (`:active`), desloca-se 4px para baixo simulando chave mecânica de arcade.
- **Secundário (Reiniciar Nível / Ferramentas):** Fundo `#102332`, borda de 1.5px em `#64E8E4`, texto em `#64E8E4`.
- **Aviso/Recompensa:** Fundo amarelo `#F9D65C`, texto `#080F1A`, utilizado para resgatar insígnias e acelerar propulsores.

### Chips e Marcadores de Sintaxe
- Elementos compactos com altura de `32px` a `36px` (com área de toque expandida para `44px` via padding invisível). Fundo `#152E42`, borda em `#275273`, ícone vetorial à esquerda (cristal, robô mascote ou estrela) e texto em `JetBrains Mono` de 12px.

### Listas e Fila de Comandos
- Itens da lista atuam como blocos conectáveis. Margens verticais de `0.5rem`, conectores visuais verticais pontilhados em `#275273`. Estados de reordenação (drag & drop) ganham contorno pontilhado ciano e escala de `1.02`.

### Caixas de Seleção e Rádio
- Tamanho físico de `24px × 24px` envelopado em área de clique de `44px × 44px`. Fundo `#080F1A`, borda de `2px` em `#64E8E4`. O marcador selecionado exibe um cristal vetorial preenchido em `#64E8E4` para checkboxes ou um núcleo estelar esférico para radio buttons.

### Campos de Entrada (Terminal e Variáveis)
- Fundo `#0A1621`, borda de `1.5px` em `#1C3B54`, fonte `JetBrains Mono` em `#EDF6FF`. Cursor em bloco piscante no padrão de terminal retro. Ao focar, a borda assume `#64E8E4` com glow suave.

### Cartões de Missão e Oficina
- Painéis em `#102332` com cabeçalho contendo a silhueta da nave ou do robô em vetor. Indicador de progresso em barra segmentada (estilo barra de energia de jogo de luta), alternando segmentos vazios e preenchidos em amarelo `#F9D65C`.